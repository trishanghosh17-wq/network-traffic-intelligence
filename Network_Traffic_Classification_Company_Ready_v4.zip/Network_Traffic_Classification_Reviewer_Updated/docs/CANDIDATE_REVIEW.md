# Candidate / company review

## What the candidate should be able to explain

- Why the current task is binary BENIGN vs DDoS.
- Why the 99.9955% result is an internal benchmark rather than production accuracy.
- Why native XGBoost importance is concentrated in two redundant CICFlowMeter variables.
- Why SHAP and permutation importance are complementary.
- Why feature selection must occur inside CV to avoid optimistic estimates.
- How threshold choice changes FPR, FNR and alert volume.
- What happens when a new/unseen attack appears.
- How the same versioned model is served by Streamlit and FastAPI.
- How external validation and drift monitoring should work.

## What the company should expect

The next engineering milestones are independent validation, genuine multi-attack training, unknown/OOD evaluation, real-time telemetry ingestion, SIEM integration, model governance and CI/CD.

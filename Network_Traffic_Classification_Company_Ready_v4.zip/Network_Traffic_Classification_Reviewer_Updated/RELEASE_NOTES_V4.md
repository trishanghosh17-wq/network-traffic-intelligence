# V4 release notes — company-oriented upgrade

Implemented:

- canonical model artifact + SHA-256/version contract;
- Streamlit and FastAPI now load the same artifact/schema;
- exact XGBoost TreeSHAP single-flow explanations;
- advisory Isolation Forest OOD screening;
- external labeled-data evaluation tab/CLI;
- operational threshold analysis and alert-rate metrics;
- local inference throughput benchmark;
- leakage-aware training pipeline with duplicate-feature removal and in-CV feature selection;
- genuine multiclass training scaffold for the full attack-family dataset;
- CI workflow and reproducible dependency/runtime files;
- API audit/logging and backward-compatible SQLite column migration;
- company-oriented architecture and model-governance documents.

Not claimed as complete:

- independent network/capture validation;
- production-real-time network telemetry ingestion;
- validated unknown-attack detection;
- genuine multiclass performance until the complete attack-family data is supplied.

from pathlib import Path
import json, time, statistics
import pandas as pd
import joblib
ROOT=Path(__file__).resolve().parents[1]; model=joblib.load(ROOT/'models/model.joblib'); features=json.loads((ROOT/'models/feature_schema.json').read_text())['features']; df=pd.read_csv(ROOT/'data/eda_sample.csv'); X=df[features].apply(pd.to_numeric,errors='coerce').replace([float('inf'),float('-inf')],float('nan'))
model.predict_proba(X.iloc[:10]); times=[]
for _ in range(10):
    t=time.perf_counter(); model.predict_proba(X); times.append(time.perf_counter()-t)
med=statistics.median(times); result={'rows':len(X),'features':len(features),'median_seconds':med,'p95_seconds':float(sorted(times)[int(.95*len(times))-1]),'throughput_flows_per_second':len(X)/med,'note':'Model-only local benchmark; excludes network, serialization and dashboard overhead.'}; print(json.dumps(result,indent=2)); (ROOT/'results/inference_benchmark.json').write_text(json.dumps(result,indent=2))

"""Train a genuine multiclass CICIDS-style attack classifier.

Put one or more labeled CICIDS2017 CSVs in data/multiclass/ and run:
    python src/train_multiclass.py

This script is intentionally separate from the current binary DDoS model so the
repository never claims multi-attack support until the full attack-family data is supplied.
"""
from __future__ import annotations
import json, os
from pathlib import Path
import joblib, numpy as np, pandas as pd
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report, confusion_matrix, f1_score, accuracy_score
from sklearn.model_selection import StratifiedGroupKFold, RandomizedSearchCV
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier

ROOT=Path(__file__).resolve().parents[1]; DATA_DIR=ROOT/'data'/'multiclass'; OUT=ROOT/'results'; MODELS=ROOT/'models'; DATA_DIR.mkdir(exist_ok=True)
files=sorted(DATA_DIR.glob('*.csv'))
if not files: raise FileNotFoundError('No multiclass CSVs found in data/multiclass/. Add the CICIDS2017 attack-family CSV files first.')
frames=[]
for f in files:
    d=pd.read_csv(f,low_memory=False); d.columns=d.columns.str.strip(); frames.append(d)
df=pd.concat(frames,ignore_index=True,sort=False)
label=next((c for c in df.columns if c.lower()=='label'),None)
if not label: raise ValueError('Label column not found')
y=df[label].astype(str).str.strip().replace({'DoS Hulk':'DoS-Hulk','DoS GoldenEye':'DoS-GoldenEye','DoS slowloris':'DoS-Slowloris','DoS Slowloris':'DoS-Slowloris','DoS Slowhttptest':'DoS-SlowHTTPTest','DoS slowhttptest':'DoS-SlowHTTPTest','Web Attack – Brute Force':'Web-Attack-BruteForce','Web Attack – XSS':'Web-Attack-XSS','Web Attack – Sql Injection':'Web-Attack-SQLi'})
X=df.drop(columns=[label]).apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
mask=~X.isna().all(axis=1); X=X.loc[mask]; y=y.loc[mask]
# Remove rows duplicated across merged files.
keep=~X.duplicated(); X=X.loc[keep]; y=y.loc[keep]
constant=[c for c in X.columns if X[c].nunique(dropna=False)<=1]; X=X.drop(columns=constant); X=X.T.drop_duplicates().T
groups=pd.util.hash_pandas_object(X.fillna(-999999999999),index=False).values
# Create class IDs with stable order.
classes=sorted(y.unique()); mapping={c:i for i,c in enumerate(classes)}; yi=y.map(mapping).astype(int)
cv=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=42); tr,te=next(cv.split(X,yi,groups)); Xtr,Xte=X.iloc[tr],X.iloc[te]; ytr,yte=yi.iloc[tr],yi.iloc[te]
k=min(50,Xtr.shape[1])
pipe=Pipeline([('imputer',SimpleImputer(strategy='median')),('selector',SelectKBest(mutual_info_classif,k=k)),('model',XGBClassifier(objective='multi:softprob',num_class=len(classes),eval_metric='mlogloss',tree_method='hist',random_state=42,n_jobs=-1))])
param={'model__n_estimators':[200,300,400],'model__max_depth':[4,6,8],'model__learning_rate':[.03,.05,.08],'model__subsample':[.8,.9,1.0],'model__colsample_bytree':[.8,.9,1.0]}
weights=ytr.value_counts(); sample_weight=ytr.map(lambda z: len(ytr)/(len(classes)*weights[int(z)])).to_numpy()
search=RandomizedSearchCV(pipe,param,n_iter=10,scoring='f1_macro',cv=cv,random_state=42,n_jobs=-1,refit=True); search.fit(Xtr,ytr,groups=groups[tr], model__sample_weight=sample_weight)
model=search.best_estimator_; pred=model.predict(Xte).astype(int); report=classification_report(yte,pred,target_names=classes,output_dict=True,zero_division=0)
out={'accuracy':accuracy_score(yte,pred),'macro_f1':f1_score(yte,pred,average='macro'),'weighted_f1':f1_score(yte,pred,average='weighted'),'classes':classes,'classification_report':report,'confusion_matrix':confusion_matrix(yte,pred).tolist(),'validation':'5-fold StratifiedGroupKFold; first group-disjoint fold used as holdout','source_files':[f.name for f in files]}
(OUT/'multiclass_metrics.json').write_text(json.dumps(out,indent=2)); (OUT/'multiclass_class_mapping.json').write_text(json.dumps(mapping,indent=2)); joblib.dump(model,MODELS/'multiclass_model.joblib',compress=3); print(json.dumps(out,indent=2))

"""Evaluate models on an independent labeled CSV.

Binary usage:
    python src/evaluate_external.py path/to/external.csv
"""
import sys
from pathlib import Path
import pandas as pd, numpy as np, joblib, json
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, average_precision_score, confusion_matrix
ROOT=Path(__file__).resolve().parents[1]
if len(sys.argv)<2: raise SystemExit('Usage: python src/evaluate_external.py path/to/external.csv')
path=Path(sys.argv[1]); model=joblib.load(ROOT/'models'/'model.joblib'); schema=json.loads((ROOT/'models'/'feature_schema.json').read_text()); features=schema['features']
df=pd.read_csv(path,low_memory=False); df.columns=df.columns.str.strip(); label=next((c for c in df.columns if c.lower()=='label'),None)
if label is None: raise SystemExit('External CSV must contain Label')
missing=[f for f in features if f not in df.columns]
if missing: raise SystemExit(f'Missing required features: {missing[:10]}')
X=df[features].apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan); y=df[label].astype(str).str.strip().str.upper().eq('DDOS').astype(int); p=model.predict_proba(X)[:,1]; pred=(p>=.5).astype(int); tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel()
out={'rows':len(df),'accuracy':accuracy_score(y,pred),'precision':precision_score(y,pred,zero_division=0),'recall':recall_score(y,pred,zero_division=0),'f1':f1_score(y,pred,zero_division=0),'roc_auc':roc_auc_score(y,p) if y.nunique()==2 else None,'pr_auc':average_precision_score(y,p) if y.nunique()==2 else None,'tn':int(tn),'fp':int(fp),'fn':int(fn),'tp':int(tp),'fpr':fp/(fp+tn) if fp+tn else 0.0,'fnr':fn/(fn+tp) if fn+tp else 0.0}
print(json.dumps(out,indent=2)); (ROOT/'results'/'latest_external_evaluation.json').write_text(json.dumps(out,indent=2))

"""Leakage-aware binary DDoS training pipeline.

Usage:
    python src/train.py

Input:
    data/DDos.pcap_ISCX.csv

Outputs (written together so deployment services stay version-consistent):
    models/model.joblib
    models/features.txt
    models/feature_schema.json
    models/model_metadata.json
    results/final_metrics.json
    results/threshold_analysis_holdout.csv
"""
from __future__ import annotations
import hashlib, json, os
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, average_precision_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import RandomizedSearchCV, StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'/'DDos.pcap_ISCX.csv'; RESULTS=ROOT/'results'; MODELS=ROOT/'models'
RESULTS.mkdir(exist_ok=True); MODELS.mkdir(exist_ok=True)
if not DATA.exists():
    raise FileNotFoundError('Training CSV not found. Place the full CICIDS2017 DDoS CSV at data/DDos.pcap_ISCX.csv')

df=pd.read_csv(DATA,low_memory=False); df.columns=df.columns.str.strip()
label=next((c for c in df.columns if c.lower()=='label'),None)
if not label: raise ValueError('Label column not found')
y=df[label].astype(str).str.strip().str.upper().eq('DDOS').astype(int)
X=df.drop(columns=[label]).apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
rows_before=len(X)
X=X.loc[~X.duplicated()].copy(); y=y.loc[X.index]
# Drop constant and exact duplicate feature columns before any split/selection.
constant=[c for c in X.columns if X[c].nunique(dropna=False)<=1]
X=X.drop(columns=constant)
X=X.T.drop_duplicates().T
if X.shape[1] < 2: raise ValueError('Too few usable features after cleaning')
groups=pd.util.hash_pandas_object(X.fillna(-999999999999),index=False).values
cv=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=42)
tr,te=next(cv.split(X,y,groups)); Xtr,Xte=X.iloc[tr],X.iloc[te]; ytr,yte=y.iloc[tr],y.iloc[te]

k=min(30,Xtr.shape[1])
selector=SelectKBest(mutual_info_classif,k=k)
base=XGBClassifier(objective='binary:logistic',eval_metric='logloss',random_state=42,n_jobs=-1)
pipe=Pipeline([('imputer',SimpleImputer(strategy='median')),('selector',selector),('model',base)])
param_dist={
    'model__n_estimators':[150,250,350,450], 'model__max_depth':[4,6,8], 'model__learning_rate':[.03,.05,.08,.1],
    'model__subsample':[.8,.9,1.0], 'model__colsample_bytree':[.8,.9,1.0], 'model__min_child_weight':[1,3,5]
}
search=RandomizedSearchCV(pipe,param_dist,n_iter=12,scoring='f1',cv=cv,random_state=42,n_jobs=-1,refit=True)
search.fit(Xtr,ytr,groups=groups[tr]); best=search.best_estimator_
prob=best.predict_proba(Xte)[:,1]; pred=(prob>=.5).astype(int)
tn,fp,fn,tp=confusion_matrix(yte,pred,labels=[0,1]).ravel()
metrics={'Accuracy':float(accuracy_score(yte,pred)),'Precision':float(precision_score(yte,pred,zero_division=0)),'Recall':float(recall_score(yte,pred,zero_division=0)),
'F1':float(f1_score(yte,pred,zero_division=0)),'ROC_AUC':float(roc_auc_score(yte,prob)),'PR_AUC':float(average_precision_score(yte,prob)),
'TN':int(tn),'FP':int(fp),'FN':int(fn),'TP':int(tp),'False_Positive_Rate':float(fp/(fp+tn)),'False_Negative_Rate':float(fn/(fn+tp)),
'Model':'Tuned XGBoost + leakage-safe in-pipeline mutual-information selection','Evaluation':'5-fold StratifiedGroupKFold; first group-disjoint fold used as final holdout','Validation_Status':'Internal group-aware holdout benchmark; not independent network/capture validation.'}
# Threshold sweep on the same holdout for analysis only.
th_rows=[]
for t in np.round(np.arange(.05,.951,.05),2):
    p=(prob>=t).astype(int); a,b,c,d=confusion_matrix(yte,p,labels=[0,1]).ravel()
    th_rows.append({'Threshold':t,'Accuracy':accuracy_score(yte,p),'Precision':precision_score(yte,p,zero_division=0),'Recall':recall_score(yte,p,zero_division=0),'F1':f1_score(yte,p,zero_division=0),'FPR':b/(a+b),'FNR':c/(c+d),'TN':a,'FP':b,'FN':c,'TP':d})
thresholds=pd.DataFrame(th_rows); thresholds.to_csv(RESULTS/'threshold_analysis_holdout.csv',index=False)
zero=thresholds[thresholds.FPR<=1e-15]
candidate=float(zero.iloc[0].Threshold) if not zero.empty else .5
# Refit deployment artifact on all cleaned data using best hyperparameters; selection remains inside the pipeline.
deploy=search.best_estimator_; deploy.fit(X,y); model_path=MODELS/'model.joblib'; joblib.dump(deploy,model_path,compress=3)
selected=list(X.columns[deploy.named_steps['selector'].get_support()])
(MODELS/'features.txt').write_text('\n'.join(selected)+'\n')
(MODELS/'feature_schema.json').write_text(json.dumps({'schema_version':'flow-features-v2','features':selected,'label':'Label'},indent=2))
sha=hashlib.sha256(model_path.read_bytes()).hexdigest()
metadata={'model_version':f'xgboost-ddos-{pd.Timestamp.utcnow().strftime("%Y%m%d%H%M%S")}','artifact':'models/model.joblib','artifact_sha256':sha,'task':'binary_classification','classes':['BENIGN','DDoS'],'feature_schema_version':'flow-features-v2','features':selected,'n_features':len(selected),'threshold_default':.5,'threshold_candidate_from_internal_holdout':candidate,'threshold_selection_rule':'First tested threshold achieving zero FPR while retaining observed holdout recall; analysis only.','validation_status':'Internal group-aware holdout; independently validate before production.','raw_rows':rows_before,'ood_status':'Rebuild advisory OOD model for the new feature schema before enabling OOD screening.','clean_rows':len(X)}
(MODELS/'model_metadata.json').write_text(json.dumps(metadata,indent=2))
(RESULTS/'final_metrics.json').write_text(json.dumps(metrics,indent=2)); (RESULTS/'final_metrics_robust.json').write_text(json.dumps(metrics,indent=2)); (RESULTS/'tuned_parameters_robust.json').write_text(json.dumps(search.best_params_,indent=2))
print(json.dumps(metrics,indent=2)); print('Saved canonical deployment artifact:',model_path); print('Selected features:',len(selected))

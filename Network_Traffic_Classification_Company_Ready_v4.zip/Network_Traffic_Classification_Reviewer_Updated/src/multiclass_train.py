"""Multi-class CICIDS2017 training scaffold.

Put the other CICIDS2017 CSV files in data/cicids2017_multiclass/ and run:
    python src/multiclass_train.py

This is intentionally separate from the bundled binary DDoS model so the current
Streamlit app never pretends it has learned attacks that are not present in its data.
"""
import glob, os, json
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from xgboost import XGBClassifier

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR=os.path.join(ROOT,'data','cicids2017_multiclass')
OUT=os.path.join(ROOT,'results'); MODEL_DIR=os.path.join(ROOT,'models')
os.makedirs(OUT,exist_ok=True); os.makedirs(MODEL_DIR,exist_ok=True)
files=glob.glob(os.path.join(DATA_DIR,'*.csv'))
if not files: raise FileNotFoundError('Add CICIDS2017 attack CSV files under data/cicids2017_multiclass/')
frames=[]
for f in files:
    d=pd.read_csv(f,low_memory=False); d.columns=d.columns.str.strip(); frames.append(d)
df=pd.concat(frames,ignore_index=True)
label=next((c for c in df.columns if c.lower()=='label'),None)
if not label: raise ValueError('No Label column found')
df[label]=df[label].astype(str).str.strip()
X=df.drop(columns=[label]).apply(pd.to_numeric,errors='coerce').replace([np.inf,-np.inf],np.nan)
X=X.loc[:,X.nunique(dropna=False)>1]; X=X.T.drop_duplicates().T
y=df[label]
enc=LabelEncoder(); yy=enc.fit_transform(y)
Xtr,Xte,ytr,yte=train_test_split(X,yy,test_size=.2,stratify=yy,random_state=42)
imp=SimpleImputer(strategy='median'); Xtr=imp.fit_transform(Xtr); Xte=imp.transform(Xte)
model=XGBClassifier(objective='multi:softprob',num_class=len(enc.classes_),n_estimators=300,max_depth=6,learning_rate=.08,subsample=.9,colsample_bytree=.9,eval_metric='mlogloss',random_state=42,n_jobs=-1)
model.fit(Xtr,ytr)
pred=model.predict(Xte)
report=classification_report(yte,pred,target_names=enc.classes_,output_dict=True,zero_division=0)
with open(os.path.join(OUT,'multiclass_classification_report.json'),'w') as f: json.dump(report,f,indent=2)
pd.DataFrame(confusion_matrix(yte,pred),index=enc.classes_,columns=enc.classes_).to_csv(os.path.join(OUT,'multiclass_confusion_matrix.csv'))
np.save(os.path.join(MODEL_DIR,'multiclass_label_classes.npy'),enc.classes_)
print('Macro F1:',f1_score(yte,pred,average='macro')); print('Classes:',list(enc.classes_))
